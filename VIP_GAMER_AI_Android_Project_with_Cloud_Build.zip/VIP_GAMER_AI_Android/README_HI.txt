VIP GAMER AI - Android starter project

Is ZIP mein Android app ka source project hai. Yeh APK file nahi hai.
Is environment mein Android SDK/Gradle build tools available nahi hain, isliye compiled APK banana mumkin nahi hua.

App features:
- UID input (default: 10386618025)
- India (IND) region label
- Player lookup demo screen
- Demo-only status; fake/live stats invent nahi kiye jaate
- No Free Fire password/OTP collection

APK banane ke liye:
1. Is ZIP ko kisi computer par extract karein.
2. Android Studio install/open karein.
3. File > Open se VIP_GAMER_AI folder select karein.
4. Android SDK Platform 35 aur compatible JDK install hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) choose karein.
6. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Important:
- Yeh official Garena app nahi hai.
- Live stats tabhi milenge jab koi legitimate, permitted stats API/data provider available ho.
- UID se stats milna guaranteed nahi hai.
- Game password ya OTP kabhi na maangein ya share karein.


ANDROID PHONE SE CLOUD APK BUILD (GitHub Actions):
1. GitHub par free account banayein / sign in karein.
2. New repository banayein (example: vip-gamer-ai).
3. ZIP extract karke uske andar ke sab files/folders repository mein upload karein. Hidden .github folder bhi upload hona chahiye.
4. Repository ke Actions tab mein jaayein. Workflow 'Build VIP GAMER AI APK' select karein.
5. 'Run workflow' dabayein (ya main branch par upload karne ke baad automatic build chalega).
6. Build successful hone par run ke neeche Artifacts mein VIP-GAMER-AI-debug-apk download karein.
7. ZIP artifact extract karein; app-debug.apk milega. Android par install karne ke liye browser/file manager ko 'Install unknown apps' permission deni pad sakti hai. Sirf apne khud ke build par bharosa karein.

Agar build fail ho, Actions ke error ka screenshot/text share karein.
