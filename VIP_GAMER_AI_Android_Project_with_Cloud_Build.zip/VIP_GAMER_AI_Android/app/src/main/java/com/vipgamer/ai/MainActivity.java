package com.vipgamer.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,9,12);
    private final int PANEL = Color.rgb(25,25,31);
    private final int RED = Color.rgb(255,48,48);
    private EditText uidInput;
    private TextView result;

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke > 0) d.setStroke(2, RED);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void gap(LinearLayout root, int h) {
        Space s = new Space(this);
        root.addView(s, new LinearLayout.LayoutParams(1, h));
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 28);
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("VIP GAMER AI", 28, RED, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("FREE FIRE PLAYER SCANNER", 12, Color.LTGRAY, true);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        gap(root, 24);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 18, 18, 18);
        card.setBackground(shape(PANEL, 24, 1));
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

        TextView title = text("PLAYER LOOKUP", 20, Color.WHITE, true);
        card.addView(title);
        gap(card, 8);
        TextView label = text("PLAYER UID", 12, Color.LTGRAY, true);
        card.addView(label);
        uidInput = new EditText(this);
        uidInput.setSingleLine(true);
        uidInput.setText("10386618025");
        uidInput.setTextColor(Color.WHITE);
        uidInput.setHintTextColor(Color.GRAY);
        uidInput.setHint("Enter player UID");
        uidInput.setInputType(2);
        uidInput.setPadding(14, 12, 14, 12);
        uidInput.setBackground(shape(Color.rgb(39,39,47), 12, 0));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = 8;
        card.addView(uidInput, ip);
        gap(card, 12);

        TextView region = text("SERVER REGION: INDIA (IND)", 13, Color.LTGRAY, true);
        card.addView(region);
        gap(card, 16);

        Button scan = new Button(this);
        scan.setText("SCAN PLAYER");
        scan.setTextColor(Color.WHITE);
        scan.setAllCaps(false);
        scan.setTextSize(16);
        scan.setBackground(shape(RED, 14, 0));
        card.addView(scan, new LinearLayout.LayoutParams(-1, 54));

        gap(root, 18);
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.VERTICAL);
        stats.setPadding(18, 18, 18, 18);
        stats.setBackground(shape(PANEL, 24, 0));
        root.addView(stats, new LinearLayout.LayoutParams(-1, -2));
        stats.addView(text("PLAYER STATISTICS", 18, Color.WHITE, true));
        gap(stats, 10);
        result = text("Enter a UID and tap SCAN PLAYER.\\n\\nDemo mode: no live account data is being fetched.", 14, Color.LTGRAY, false);
        stats.addView(result);
        gap(root, 14);
        TextView note = text("DEMO MODE  •  API NOT CONNECTED", 12, RED, true);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
        gap(root, 12);
        TextView safety = text("This is an independent demo app, not an official Garena product. Never enter your game password or OTP.", 11, Color.GRAY, false);
        safety.setGravity(Gravity.CENTER);
        root.addView(safety);

        scan.setOnClickListener(v -> {
            String uid = uidInput.getText().toString().trim();
            if (!uid.matches("\\d{5,15}")) {
                uidInput.setError("Enter a valid 5–15 digit UID");
                return;
            }
            result.setText(
                "UID: " + uid +
                "\\nRegion: India (IND)" +
                "\\nPlayer name: Not available" +
                "\\nLevel: Not available" +
                "\\nRank: Not available" +
                "\\nBR matches: Not available" +
                "\\nWin rate: Not available" +
                "\\nK/D ratio: Not available" +
                "\\n\\nDemo only — connect a legitimate stats data provider to show verified live data."
            );
        });
    }
}
